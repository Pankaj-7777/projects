import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import Header from './components/common/Header';
import Dashboard from './components/Dashboard';
import ExpenseList from './components/ExpenseList';
import UserManagement from './components/UserManagement';
import SettlementView from './components/SettlementView';
import StatisticsView from './components/StatisticsView';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <AppProvider>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100">
        <Header activeTab={activeTab} setActiveTab={setActiveTab} />
        
        <main className="container mx-auto px-4 pt-24 pb-12 max-w-7xl">
          {activeTab === 'dashboard' && <Dashboard />}
          {activeTab === 'expenses' && <ExpenseList />}
          {activeTab === 'people' && <UserManagement />}
          {activeTab === 'settlements' && <SettlementView />}
          {activeTab === 'statistics' && <StatisticsView />}
        </main>
      </div>
    </AppProvider>
  );
}

export default App;