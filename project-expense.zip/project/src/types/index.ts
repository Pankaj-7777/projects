export interface User {
  id: string;
  name: string;
  email?: string;
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  paidBy: string; // User ID
  date: string;
  category: string;
  participants: {
    userId: string;
    amount: number;
  }[];
  splitMethod: 'equal' | 'custom' | 'percentage';
  notes?: string;
}

export interface Settlement {
  from: string; // User ID
  to: string; // User ID
  amount: number;
}

export interface Balance {
  userId: string;
  amount: number;
}