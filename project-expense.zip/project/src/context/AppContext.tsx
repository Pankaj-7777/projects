import React, { createContext, useContext, ReactNode, useState, useEffect } from 'react';
import { User, Expense, Settlement, Balance } from '../types';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { calculateBalances, calculateSettlements, generateId } from '../utils/calculations';

interface AppContextType {
  users: User[];
  expenses: Expense[];
  balances: Balance[];
  settlements: Settlement[];
  theme: 'light' | 'dark';
  addUser: (user: Omit<User, 'id'>) => void;
  updateUser: (user: User) => void;
  removeUser: (id: string) => void;
  addExpense: (expense: Omit<Expense, 'id'>) => void;
  updateExpense: (expense: Expense) => void;
  removeExpense: (id: string) => void;
  getUserById: (id: string) => User | undefined;
  toggleTheme: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [users, setUsers] = useLocalStorage<User[]>('expense-splitter-users', []);
  const [expenses, setExpenses] = useLocalStorage<Expense[]>('expense-splitter-expenses', []);
  const [balances, setBalances] = useState<Balance[]>([]);
  const [settlements, setSettlements] = useState<Settlement[]>([]);
  const [theme, setTheme] = useLocalStorage<'light' | 'dark'>('expense-splitter-theme', 'light');

  // Calculate balances and settlements whenever users or expenses change
  useEffect(() => {
    const newBalances = calculateBalances(expenses, users);
    setBalances(newBalances);
    
    const newSettlements = calculateSettlements(newBalances);
    setSettlements(newSettlements);
  }, [users, expenses]);

  // Apply theme to document
  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
  }, [theme]);

  const addUser = (user: Omit<User, 'id'>) => {
    const newUser = { ...user, id: generateId() };
    setUsers(prev => [...prev, newUser]);
  };

  const updateUser = (user: User) => {
    setUsers(prev => prev.map(u => (u.id === user.id ? user : u)));
  };

  const removeUser = (id: string) => {
    setUsers(prev => prev.filter(user => user.id !== id));
  };

  const addExpense = (expense: Omit<Expense, 'id'>) => {
    const newExpense = { ...expense, id: generateId() };
    setExpenses(prev => [...prev, newExpense]);
  };

  const updateExpense = (expense: Expense) => {
    setExpenses(prev => prev.map(e => (e.id === expense.id ? expense : e)));
  };

  const removeExpense = (id: string) => {
    setExpenses(prev => prev.filter(expense => expense.id !== id));
  };

  const getUserById = (id: string) => {
    return users.find(user => user.id === id);
  };

  const toggleTheme = () => {
    setTheme(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  return (
    <AppContext.Provider
      value={{
        users,
        expenses,
        balances,
        settlements,
        theme,
        addUser,
        updateUser,
        removeUser,
        addExpense,
        updateExpense,
        removeExpense,
        getUserById,
        toggleTheme,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};