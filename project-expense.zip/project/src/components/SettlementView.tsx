import React from 'react';
import { CreditCard, ChevronRight, ChevronDown, Wallet, AlertTriangle } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Card from './common/Card';
import Button from './common/Button';
import { formatCurrency } from '../utils/calculations';
import { Settlement } from '../types';

const SettlementView: React.FC = () => {
  const { settlements, users, balances, getUserById } = useAppContext();
  const [expandedSection, setExpandedSection] = React.useState<string | null>('settlements');

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  // Get the user name by ID
  const getUserName = (id: string) => {
    const user = getUserById(id);
    return user ? user.name : 'Unknown';
  };

  const hasSettlements = settlements.length > 0;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Settlements</h2>

      {/* Section: Settlements */}
      <Card className="overflow-hidden">
        <div 
          className="flex justify-between items-center cursor-pointer"
          onClick={() => toggleSection('settlements')}
        >
          <div className="flex items-center space-x-2">
            <CreditCard className="text-indigo-500" size={20} />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
              Payment Summary
            </h3>
          </div>
          <button className="p-1 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
            {expandedSection === 'settlements' ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
          </button>
        </div>

        {expandedSection === 'settlements' && (
          <div className="mt-4 space-y-4">
            {!hasSettlements ? (
              <div className="text-center py-6">
                <Wallet size={40} className="mx-auto text-gray-400 mb-2" />
                <p className="text-gray-600 dark:text-gray-300 mb-1">All settled up!</p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  There are no outstanding balances between members.
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {settlements.map((settlement: Settlement, index) => (
                  <div 
                    key={`${settlement.from}-${settlement.to}-${index}`}
                    className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-750 rounded-lg border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:shadow-md"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-9 h-9 flex items-center justify-center bg-indigo-100 dark:bg-indigo-900/30 text-indigo-500 rounded-full">
                        <CreditCard size={18} />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="font-medium text-gray-900 dark:text-gray-100">
                            {getUserName(settlement.from)}
                          </span>
                          <ChevronRight size={16} className="text-gray-400" />
                          <span className="font-medium text-gray-900 dark:text-gray-100">
                            {getUserName(settlement.to)}
                          </span>
                        </div>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Payment required
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-gray-900 dark:text-gray-100">
                        {formatCurrency(settlement.amount)}
                      </div>
                    </div>
                  </div>
                ))}

                <div className="mt-6 flex justify-center">
                  <Button 
                    variant="outline"
                    leftIcon={<Wallet size={16} />}
                    onClick={() => window.print()}
                  >
                    Export Settlement Report
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </Card>

      {/* Section: Individual Balances */}
      <Card className="overflow-hidden">
        <div 
          className="flex justify-between items-center cursor-pointer"
          onClick={() => toggleSection('balances')}
        >
          <div className="flex items-center space-x-2">
            <Wallet className="text-teal-500" size={20} />
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
              Individual Balances
            </h3>
          </div>
          <button className="p-1 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
            {expandedSection === 'balances' ? <ChevronDown size={20} /> : <ChevronRight size={20} />}
          </button>
        </div>

        {expandedSection === 'balances' && (
          <div className="mt-4">
            <div className="border rounded-lg overflow-hidden">
              <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead className="bg-gray-50 dark:bg-gray-800">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Person
                    </th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Balance
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                  {balances.map(balance => {
                    const user = getUserById(balance.userId);
                    if (!user) return null;
                    
                    const isPositive = balance.amount > 0;
                    const isZero = Math.abs(balance.amount) < 0.01;
                    
                    let statusColor = 'text-gray-800 dark:text-gray-200';
                    if (isPositive) statusColor = 'text-green-600 dark:text-green-400';
                    if (balance.amount < 0) statusColor = 'text-red-600 dark:text-red-400';
                    
                    return (
                      <tr key={balance.userId} className="hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {user.name}
                          </div>
                        </td>
                        <td className={`px-6 py-4 whitespace-nowrap text-sm text-right font-medium ${statusColor}`}>
                          {isZero ? 'Settled' : formatCurrency(balance.amount)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            
            <div className="mt-4 p-3 rounded-lg border border-amber-200 bg-amber-50 dark:bg-amber-900/20 dark:border-amber-800/50">
              <div className="flex space-x-2">
                <div className="flex-shrink-0 mt-0.5">
                  <AlertTriangle size={16} className="text-amber-500" />
                </div>
                <div className="text-sm text-amber-800 dark:text-amber-200">
                  <p className="font-medium">Understanding balances</p>
                  <p className="mt-0.5">
                    Positive balance means you are owed money. Negative balance means you owe money to others.
                    Totals are calculated based on all expenses in the system.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default SettlementView;