import React, { useState } from 'react';
import { User, UserCircle, UserPlus, X, Edit, Trash } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Card from './common/Card';
import Button from './common/Button';
import Modal from './common/Modal';

const UserManagement: React.FC = () => {
  const { users, addUser, updateUser, removeUser } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<{ id?: string; name: string; email: string }>({
    name: '',
    email: '',
  });
  const [isEditing, setIsEditing] = useState(false);

  const handleOpenModal = (edit = false, user?: { id: string; name: string; email?: string }) => {
    if (edit && user) {
      setCurrentUser({ id: user.id, name: user.name, email: user.email || '' });
      setIsEditing(true);
    } else {
      setCurrentUser({ name: '', email: '' });
      setIsEditing(false);
    }
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (isEditing && currentUser.id) {
      updateUser({
        id: currentUser.id,
        name: currentUser.name,
        email: currentUser.email || undefined,
      });
    } else {
      addUser({
        name: currentUser.name,
        email: currentUser.email || undefined,
      });
    }
    
    setIsModalOpen(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to remove this person? This will affect all expenses they are part of.')) {
      removeUser(id);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">People</h2>
        <Button 
          variant="primary" 
          onClick={() => handleOpenModal()} 
          leftIcon={<UserPlus size={16} />}
        >
          Add Person
        </Button>
      </div>

      {users.length === 0 ? (
        <Card className="text-center py-8">
          <User size={48} className="mx-auto text-gray-400 mb-3" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">No people added yet</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">Add people to start tracking expenses and splitting bills.</p>
          <Button 
            variant="primary" 
            onClick={() => handleOpenModal()} 
            leftIcon={<UserPlus size={16} />}
          >
            Add Person
          </Button>
        </Card>
      ) : (
        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {users.map((user) => (
            <Card key={user.id} isHoverable className="flex flex-col">
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-indigo-100 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-300 rounded-full flex items-center justify-center">
                    <UserCircle size={20} />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900 dark:text-gray-100">{user.name}</h3>
                    {user.email && (
                      <p className="text-sm text-gray-500 dark:text-gray-400">{user.email}</p>
                    )}
                  </div>
                </div>
                <div className="flex space-x-1">
                  <button 
                    className="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                    onClick={() => handleOpenModal(true, user)}
                    aria-label="Edit person"
                  >
                    <Edit size={16} />
                  </button>
                  <button 
                    className="p-1 text-gray-400 hover:text-red-600 dark:hover:text-red-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                    onClick={() => handleDelete(user.id)}
                    aria-label="Remove person"
                  >
                    <Trash size={16} />
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      {/* Add/Edit Person Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={isEditing ? 'Edit Person' : 'Add Person'}
        footer={
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setIsModalOpen(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleSubmit}>
              {isEditing ? 'Update' : 'Add'}
            </Button>
          </div>
        }
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Name
            </label>
            <input
              id="name"
              type="text"
              value={currentUser.name}
              onChange={(e) => setCurrentUser({ ...currentUser, name: e.target.value })}
              className="w-full rounded-md border border-gray-300 dark:border-gray-600 px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-teal-500"
              required
            />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Email (optional)
            </label>
            <input
              id="email"
              type="email"
              value={currentUser.email}
              onChange={(e) => setCurrentUser({ ...currentUser, email: e.target.value })}
              className="w-full rounded-md border border-gray-300 dark:border-gray-600 px-3 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default UserManagement;