import React from 'react';
import { TrendingUp, Receipt, User, DollarSign, CreditCard } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Card from './common/Card';
import { formatCurrency } from '../utils/calculations';

const Dashboard: React.FC = () => {
  const { expenses, users, balances } = useAppContext();

  // Calculate total expenses
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);

  // Calculate number of expenses
  const expenseCount = expenses.length;

  // Calculate average expense amount
  const averageExpense = expenseCount > 0 ? totalExpenses / expenseCount : 0;

  // Get most frequent category
  const categoryCount: Record<string, number> = {};
  expenses.forEach(expense => {
    categoryCount[expense.category] = (categoryCount[expense.category] || 0) + 1;
  });
  
  const mostFrequentCategory = Object.entries(categoryCount).sort((a, b) => b[1] - a[1])[0]?.[0] || 'None';

  // Get biggest spender
  const userExpenses: Record<string, number> = {};
  expenses.forEach(expense => {
    userExpenses[expense.paidBy] = (userExpenses[expense.paidBy] || 0) + expense.amount;
  });
  
  const biggestSpenderId = Object.entries(userExpenses).sort((a, b) => b[1] - a[1])[0]?.[0];
  const biggestSpender = users.find(user => user.id === biggestSpenderId)?.name || 'Unknown';
  
  // Get positive and negative balances
  const positiveBalances = balances.filter(b => b.amount > 0);
  const negativeBalances = balances.filter(b => b.amount < 0);

  // Recent expenses (last 5)
  const recentExpenses = [...expenses]
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Dashboard</h2>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-teal-50 to-teal-100 dark:from-teal-900/30 dark:to-teal-800/20 border border-teal-200 dark:border-teal-700/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-teal-800 dark:text-teal-300">Total Expenses</p>
              <p className="text-2xl font-bold text-teal-900 dark:text-teal-200 mt-1">
                {formatCurrency(totalExpenses)}
              </p>
            </div>
            <div className="w-12 h-12 bg-teal-200 dark:bg-teal-800/50 rounded-full flex items-center justify-center text-teal-700 dark:text-teal-300">
              <DollarSign size={24} />
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-indigo-50 to-indigo-100 dark:from-indigo-900/30 dark:to-indigo-800/20 border border-indigo-200 dark:border-indigo-700/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-indigo-800 dark:text-indigo-300">Expense Count</p>
              <p className="text-2xl font-bold text-indigo-900 dark:text-indigo-200 mt-1">
                {expenseCount}
              </p>
            </div>
            <div className="w-12 h-12 bg-indigo-200 dark:bg-indigo-800/50 rounded-full flex items-center justify-center text-indigo-700 dark:text-indigo-300">
              <Receipt size={24} />
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 dark:from-purple-900/30 dark:to-purple-800/20 border border-purple-200 dark:border-purple-700/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-purple-800 dark:text-purple-300">Average Expense</p>
              <p className="text-2xl font-bold text-purple-900 dark:text-purple-200 mt-1">
                {formatCurrency(averageExpense)}
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-200 dark:bg-purple-800/50 rounded-full flex items-center justify-center text-purple-700 dark:text-purple-300">
              <TrendingUp size={24} />
            </div>
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-pink-50 to-pink-100 dark:from-pink-900/30 dark:to-pink-800/20 border border-pink-200 dark:border-pink-700/30">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-pink-800 dark:text-pink-300">People</p>
              <p className="text-2xl font-bold text-pink-900 dark:text-pink-200 mt-1">
                {users.length}
              </p>
            </div>
            <div className="w-12 h-12 bg-pink-200 dark:bg-pink-800/50 rounded-full flex items-center justify-center text-pink-700 dark:text-pink-300">
              <User size={24} />
            </div>
          </div>
        </Card>
      </div>

      {/* Additional Stats and Recent Expenses */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: More Stats */}
        <div className="space-y-5 lg:col-span-1">
          <Card heading="Quick Stats">
            <div className="space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">Most Frequent Category</span>
                <span className="font-medium text-gray-900 dark:text-gray-100">{mostFrequentCategory}</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">Biggest Spender</span>
                <span className="font-medium text-gray-900 dark:text-gray-100">{biggestSpender}</span>
              </div>
              <div className="flex justify-between items-center pb-3 border-b border-gray-100 dark:border-gray-700">
                <span className="text-sm text-gray-500 dark:text-gray-400">People with positive balance</span>
                <span className="font-medium text-gray-900 dark:text-gray-100">{positiveBalances.length}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-500 dark:text-gray-400">People with negative balance</span>
                <span className="font-medium text-gray-900 dark:text-gray-100">{negativeBalances.length}</span>
              </div>
            </div>
          </Card>

          <Card heading="Settlement Status" className="h-[calc(100%-5rem)]">
            {balances.length === 0 ? (
              <div className="text-center py-6">
                <CreditCard size={32} className="mx-auto text-gray-400 mb-2" />
                <p className="text-gray-500 dark:text-gray-400">No balances to show</p>
              </div>
            ) : (
              <div className="space-y-3">
                {balances.map(balance => {
                  const user = users.find(u => u.id === balance.userId);
                  if (!user) return null;
                  
                  const isPositive = balance.amount > 0;
                  const isZero = Math.abs(balance.amount) < 0.01;
                  
                  return (
                    <div key={balance.userId} className="flex justify-between items-center">
                      <span className="text-sm text-gray-800 dark:text-gray-200">{user.name}</span>
                      <span className={`font-medium ${
                        isZero 
                          ? 'text-gray-500 dark:text-gray-400' 
                          : isPositive 
                            ? 'text-green-600 dark:text-green-400' 
                            : 'text-red-600 dark:text-red-400'
                      }`}>
                        {isZero ? 'Settled' : formatCurrency(balance.amount)}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>
        </div>

        {/* Right column: Recent Expenses */}
        <Card heading="Recent Expenses" className="lg:col-span-2">
          {recentExpenses.length === 0 ? (
            <div className="text-center py-6">
              <Receipt size={32} className="mx-auto text-gray-400 mb-2" />
              <p className="text-gray-500 dark:text-gray-400">No expenses to show</p>
            </div>
          ) : (
            <div className="space-y-4">
              {recentExpenses.map(expense => {
                const paidBy = users.find(user => user.id === expense.paidBy);
                return (
                  <div 
                    key={expense.id}
                    className="flex items-center justify-between p-3 rounded-lg border border-gray-200 dark:border-gray-700 transition-all duration-300 hover:bg-gray-50 dark:hover:bg-gray-750"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 flex items-center justify-center bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 rounded-full">
                        <Receipt size={20} />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 dark:text-gray-100">{expense.title}</h4>
                        <p className="text-sm text-gray-500 dark:text-gray-400">
                          Paid by {paidBy?.name || 'Unknown'} • {new Date(expense.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-semibold text-gray-900 dark:text-gray-100">
                        {formatCurrency(expense.amount)}
                      </div>
                      <div className="text-xs text-gray-500 dark:text-gray-400">
                        {expense.participants.length} participants
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;