import React, { useState, useEffect } from 'react';
import { Calendar, DollarSign, Tag, FileText, Users, ArrowRight } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Button from './common/Button';
import { Expense } from '../types';
import { generateId, splitEqually } from '../utils/calculations';

interface ExpenseFormProps {
  expense?: Expense;
  onSave: () => void;
  onCancel: () => void;
}

const categories = [
  'Food & Drink',
  'Groceries',
  'Transportation',
  'Housing',
  'Utilities',
  'Entertainment',
  'Shopping',
  'Personal',
  'Travel',
  'Other',
];

const ExpenseForm: React.FC<ExpenseFormProps> = ({ expense, onSave, onCancel }) => {
  const { users, addExpense, updateExpense } = useAppContext();
  const isEditing = !!expense;

  const [title, setTitle] = useState(expense?.title || '');
  const [amount, setAmount] = useState(expense?.amount.toString() || '');
  const [paidBy, setPaidBy] = useState(expense?.paidBy || '');
  const [date, setDate] = useState(expense?.date || new Date().toISOString().slice(0, 10));
  const [category, setCategory] = useState(expense?.category || 'Other');
  const [notes, setNotes] = useState(expense?.notes || '');
  const [splitMethod, setSplitMethod] = useState<'equal' | 'custom' | 'percentage'>(
    expense?.splitMethod || 'equal'
  );
  
  const [selectedParticipants, setSelectedParticipants] = useState<string[]>(
    expense ? expense.participants.map(p => p.userId) : []
  );
  
  const [customAmounts, setCustomAmounts] = useState<Record<string, string>>(
    expense
      ? expense.participants.reduce((acc, p) => ({ ...acc, [p.userId]: p.amount.toString() }), {})
      : {}
  );

  const [errors, setErrors] = useState<Record<string, string>>({});

  // Select all users as participants by default for new expenses
  useEffect(() => {
    if (!isEditing && users.length > 0) {
      setSelectedParticipants(users.map(user => user.id));
      
      // If no payer is selected, select the first user
      if (!paidBy && users.length > 0) {
        setPaidBy(users[0].id);
      }
    }
  }, [users, isEditing, paidBy]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!title) newErrors.title = 'Title is required';
    if (!amount || isNaN(parseFloat(amount)) || parseFloat(amount) <= 0) {
      newErrors.amount = 'Enter a valid amount';
    }
    if (!paidBy) newErrors.paidBy = 'Select who paid';
    if (!date) newErrors.date = 'Date is required';
    if (selectedParticipants.length === 0) {
      newErrors.participants = 'Select at least one participant';
    }

    // Validate custom splits if applicable
    if (splitMethod === 'custom') {
      let totalSplit = 0;
      let hasInvalidAmount = false;

      selectedParticipants.forEach(userId => {
        const userAmount = parseFloat(customAmounts[userId] || '0');
        if (isNaN(userAmount) || userAmount < 0) {
          hasInvalidAmount = true;
        } else {
          totalSplit += userAmount;
        }
      });

      if (hasInvalidAmount) {
        newErrors.customSplit = 'All amounts must be valid numbers';
      } else if (Math.abs(totalSplit - parseFloat(amount)) > 0.01) {
        newErrors.customSplit = `Total split must equal the expense amount (${parseFloat(amount).toFixed(2)})`;
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    const numericAmount = parseFloat(amount);
    
    let participants = selectedParticipants.map(userId => ({
      userId,
      amount: 0, // Placeholder, will be updated below
    }));
    
    let newExpense: Omit<Expense, 'id'> = {
      title,
      amount: numericAmount,
      paidBy,
      date,
      category,
      splitMethod,
      notes: notes.trim() || undefined,
      participants: [],
    };
    
    // Calculate split based on the selected method
    if (splitMethod === 'equal') {
      const equalExpense = splitEqually(
        { ...newExpense, id: expense?.id || generateId() }, 
        selectedParticipants
      );
      newExpense.participants = equalExpense.participants;
    } else if (splitMethod === 'custom') {
      newExpense.participants = selectedParticipants.map(userId => ({
        userId,
        amount: parseFloat(customAmounts[userId] || '0'),
      }));
    } else if (splitMethod === 'percentage') {
      // Implement percentage-based splitting logic here if needed
      // For now, defaulting to equal split
      const equalExpense = splitEqually(
        { ...newExpense, id: expense?.id || generateId() }, 
        selectedParticipants
      );
      newExpense.participants = equalExpense.participants;
    }
    
    if (isEditing && expense) {
      updateExpense({ ...newExpense, id: expense.id });
    } else {
      addExpense(newExpense);
    }
    
    onSave();
  };

  const handleParticipantToggle = (userId: string) => {
    if (selectedParticipants.includes(userId)) {
      setSelectedParticipants(prev => prev.filter(id => id !== userId));
    } else {
      setSelectedParticipants(prev => [...prev, userId]);
    }
  };

  const handleSelectAll = () => {
    setSelectedParticipants(users.map(user => user.id));
  };

  const handleUnselectAll = () => {
    setSelectedParticipants([]);
  };

  const calculateEqualSplit = () => {
    if (selectedParticipants.length === 0 || !amount) return 0;
    return parseFloat(amount) / selectedParticipants.length;
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        {/* Title */}
        <div>
          <label htmlFor="title" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Expense Title
          </label>
          <div className="relative rounded-md shadow-sm">
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className={`block w-full rounded-md border ${
                errors.title ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 dark:border-gray-600 focus:border-teal-500 focus:ring-teal-500'
              } px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2`}
              placeholder="Dinner, Movie tickets, etc."
            />
          </div>
          {errors.title && <p className="mt-1 text-sm text-red-600">{errors.title}</p>}
        </div>

        {/* Amount and Paid By */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="amount" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Amount
            </label>
            <div className="relative rounded-md shadow-sm">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <DollarSign size={16} className="text-gray-500" />
              </div>
              <input
                type="text"
                id="amount"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className={`block w-full rounded-md border ${
                  errors.amount ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 dark:border-gray-600 focus:border-teal-500 focus:ring-teal-500'
                } pl-10 px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2`}
                placeholder="0.00"
              />
            </div>
            {errors.amount && <p className="mt-1 text-sm text-red-600">{errors.amount}</p>}
          </div>

          <div>
            <label htmlFor="paidBy" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Paid By
            </label>
            <select
              id="paidBy"
              value={paidBy}
              onChange={(e) => setPaidBy(e.target.value)}
              className={`block w-full rounded-md border ${
                errors.paidBy ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 dark:border-gray-600 focus:border-teal-500 focus:ring-teal-500'
              } px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2`}
            >
              <option value="">Select who paid</option>
              {users.map(user => (
                <option key={user.id} value={user.id}>{user.name}</option>
              ))}
            </select>
            {errors.paidBy && <p className="mt-1 text-sm text-red-600">{errors.paidBy}</p>}
          </div>
        </div>

        {/* Date and Category */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Date
            </label>
            <div className="relative rounded-md shadow-sm">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Calendar size={16} className="text-gray-500" />
              </div>
              <input
                type="date"
                id="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`block w-full rounded-md border ${
                  errors.date ? 'border-red-300 focus:border-red-500 focus:ring-red-500' : 'border-gray-300 dark:border-gray-600 focus:border-teal-500 focus:ring-teal-500'
                } pl-10 px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2`}
              />
            </div>
            {errors.date && <p className="mt-1 text-sm text-red-600">{errors.date}</p>}
          </div>

          <div>
            <label htmlFor="category" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Category
            </label>
            <div className="relative rounded-md shadow-sm">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Tag size={16} className="text-gray-500" />
              </div>
              <select
                id="category"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="block w-full rounded-md border border-gray-300 dark:border-gray-600 pl-10 px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:border-teal-500 focus:ring-teal-500"
              >
                {categories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Notes */}
        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Notes (optional)
          </label>
          <div className="relative rounded-md shadow-sm">
            <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
              <FileText size={16} className="text-gray-500" />
            </div>
            <textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="block w-full rounded-md border border-gray-300 dark:border-gray-600 pl-10 px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:border-teal-500 focus:ring-teal-500"
              placeholder="Any additional details..."
              rows={2}
            />
          </div>
        </div>

        {/* Split Method */}
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Split Method
          </label>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setSplitMethod('equal')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                splitMethod === 'equal'
                  ? 'bg-teal-100 text-teal-800 dark:bg-teal-900/40 dark:text-teal-300'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              Equal
            </button>
            <button
              type="button"
              onClick={() => setSplitMethod('custom')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                splitMethod === 'custom'
                  ? 'bg-teal-100 text-teal-800 dark:bg-teal-900/40 dark:text-teal-300'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-800 dark:text-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              Custom
            </button>
          </div>
        </div>

        {/* Participants */}
        <div>
          <div className="flex justify-between items-center mb-2">
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
              Participants
            </label>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleSelectAll}
                className="text-xs text-teal-600 dark:text-teal-400 hover:text-teal-800 dark:hover:text-teal-300"
              >
                Select All
              </button>
              <span className="text-gray-300 dark:text-gray-600">|</span>
              <button
                type="button"
                onClick={handleUnselectAll}
                className="text-xs text-teal-600 dark:text-teal-400 hover:text-teal-800 dark:hover:text-teal-300"
              >
                Clear All
              </button>
            </div>
          </div>

          <div className="border border-gray-200 dark:border-gray-700 rounded-md overflow-hidden mb-1">
            <div className="grid grid-cols-1 divide-y divide-gray-200 dark:divide-gray-700">
              {users.map(user => (
                <div 
                  key={user.id} 
                  className={`px-4 py-3 flex items-center justify-between ${
                    selectedParticipants.includes(user.id) ? 'bg-teal-50 dark:bg-teal-900/20' : 'bg-white dark:bg-gray-800'
                  }`}
                >
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id={`participant-${user.id}`}
                      checked={selectedParticipants.includes(user.id)}
                      onChange={() => handleParticipantToggle(user.id)}
                      className="h-4 w-4 text-teal-600 focus:ring-teal-500 border-gray-300 rounded"
                    />
                    <label htmlFor={`participant-${user.id}`} className="ml-3 text-sm text-gray-700 dark:text-gray-200">
                      {user.name}
                    </label>
                  </div>

                  {splitMethod === 'equal' && selectedParticipants.includes(user.id) && (
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(calculateEqualSplit())}
                    </span>
                  )}

                  {splitMethod === 'custom' && selectedParticipants.includes(user.id) && (
                    <div className="w-24">
                      <input
                        type="text"
                        value={customAmounts[user.id] || ''}
                        onChange={(e) => setCustomAmounts({ ...customAmounts, [user.id]: e.target.value })}
                        className="block w-full rounded-md border border-gray-300 dark:border-gray-600 px-2 py-1 text-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-1 focus:border-teal-500 focus:ring-teal-500"
                        placeholder="0.00"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {errors.participants && <p className="mt-1 text-sm text-red-600">{errors.participants}</p>}
          {errors.customSplit && <p className="mt-1 text-sm text-red-600">{errors.customSplit}</p>}
        </div>
      </div>

      <div className="flex justify-end space-x-2 pt-2">
        <Button variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button variant="primary" type="submit">
          {isEditing ? 'Update Expense' : 'Add Expense'}
        </Button>
      </div>
    </form>
  );
};

export default ExpenseForm;