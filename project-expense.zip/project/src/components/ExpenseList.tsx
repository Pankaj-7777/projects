import React, { useState } from 'react';
import { PlusCircle, Filter, Edit, Trash, DollarSign, Tag, Receipt, Calendar, Search } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Card from './common/Card';
import Button from './common/Button';
import Modal from './common/Modal';
import ExpenseForm from './ExpenseForm';
import { formatCurrency, formatDate } from '../utils/calculations';

const ExpenseList: React.FC = () => {
  const { expenses, users, removeExpense, getUserById } = useAppContext();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentExpense, setCurrentExpense] = useState<any>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');

  const handleOpenModal = (expense?: any) => {
    setCurrentExpense(expense || null);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Are you sure you want to delete this expense?')) {
      removeExpense(id);
    }
  };

  const categories = [
    'All Categories',
    'Food & Drink',
    'Groceries',
    'Transportation',
    'Housing',
    'Utilities',
    'Entertainment',
    'Shopping',
    'Personal',
    'Travel',
    'Other',
  ];

  // Filter expenses based on search term and category
  const filteredExpenses = expenses.filter(expense => {
    const matchesSearch = expense.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          (expense.notes || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === '' || filterCategory === 'All Categories' || 
                            expense.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  // Sort expenses by date (newest first)
  const sortedExpenses = [...filteredExpenses].sort((a, b) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Expenses</h2>
        <Button 
          variant="primary" 
          onClick={() => handleOpenModal()} 
          leftIcon={<PlusCircle size={16} />}
        >
          Add Expense
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Search */}
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <Search size={16} className="text-gray-500" />
          </div>
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="block w-full rounded-md border border-gray-300 dark:border-gray-600 pl-10 px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:border-teal-500 focus:ring-teal-500"
            placeholder="Search expenses..."
          />
        </div>

        {/* Category Filter */}
        <div className="relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <Filter size={16} className="text-gray-500" />
          </div>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="block w-full rounded-md border border-gray-300 dark:border-gray-600 pl-10 px-4 py-2 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:border-teal-500 focus:ring-teal-500"
          >
            {categories.map(category => (
              <option key={category} value={category}>
                {category}
              </option>
            ))}
          </select>
        </div>
      </div>

      {expenses.length === 0 ? (
        <Card className="text-center py-8">
          <Receipt size={48} className="mx-auto text-gray-400 mb-3" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">No expenses added yet</h3>
          <p className="text-gray-500 dark:text-gray-400 mb-4">Start adding expenses to track your spending and split bills with friends.</p>
          <Button 
            variant="primary" 
            onClick={() => handleOpenModal()} 
            leftIcon={<PlusCircle size={16} />}
          >
            Add Expense
          </Button>
        </Card>
      ) : (
        <>
          {sortedExpenses.length === 0 ? (
            <Card className="text-center py-6">
              <Search size={32} className="mx-auto text-gray-400 mb-2" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">No matching expenses</h3>
              <p className="text-gray-500 dark:text-gray-400">Try adjusting your search or filter criteria.</p>
            </Card>
          ) : (
            <div className="space-y-4">
              {sortedExpenses.map(expense => {
                const paidBy = getUserById(expense.paidBy);
                return (
                  <Card key={expense.id} isHoverable className="transition-all duration-300">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between">
                      <div className="space-y-2 mb-3 sm:mb-0">
                        <div className="flex items-center">
                          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">{expense.title}</h3>
                          <span className="ml-2 px-2 py-0.5 text-xs rounded-full bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
                            {expense.category}
                          </span>
                        </div>
                        
                        <div className="text-sm text-gray-500 dark:text-gray-400 space-y-1">
                          <div className="flex items-center">
                            <Calendar size={14} className="mr-1" />
                            <span>{formatDate(expense.date)}</span>
                          </div>
                          <div className="flex items-center">
                            <DollarSign size={14} className="mr-1" />
                            <span>Paid by {paidBy?.name || 'Unknown'}</span>
                          </div>
                        </div>
                        
                        {expense.notes && (
                          <p className="text-sm text-gray-500 dark:text-gray-400 italic">
                            "{expense.notes}"
                          </p>
                        )}
                      </div>

                      <div className="flex sm:flex-col items-center sm:items-end space-x-3 sm:space-x-0 sm:space-y-3">
                        <div className="text-xl font-semibold text-gray-900 dark:text-gray-100">
                          {formatCurrency(expense.amount)}
                        </div>
                        <div className="flex space-x-1">
                          <button 
                            className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                            onClick={() => handleOpenModal(expense)}
                            aria-label="Edit expense"
                          >
                            <Edit size={18} />
                          </button>
                          <button 
                            className="p-1.5 text-gray-400 hover:text-red-600 dark:hover:text-red-400 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800"
                            onClick={() => handleDelete(expense.id)}
                            aria-label="Delete expense"
                          >
                            <Trash size={18} />
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                      <div className="text-xs text-gray-500 dark:text-gray-400 mb-1">
                        Split {expense.splitMethod === 'equal' ? 'equally' : 'custom'} between {expense.participants.length} people
                      </div>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {expense.participants.map(participant => {
                          const user = getUserById(participant.userId);
                          return user ? (
                            <div key={participant.userId} className="bg-gray-100 dark:bg-gray-700 px-2 py-1 rounded-full text-xs text-gray-800 dark:text-gray-200">
                              {user.name}: {formatCurrency(participant.amount)}
                            </div>
                          ) : null;
                        })}
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>
          )}
        </>
      )}

      {/* Add/Edit Expense Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={currentExpense ? 'Edit Expense' : 'Add Expense'}
        size="lg"
      >
        <ExpenseForm
          expense={currentExpense}
          onSave={() => setIsModalOpen(false)}
          onCancel={() => setIsModalOpen(false)}
        />
      </Modal>
    </div>
  );
};

export default ExpenseList;