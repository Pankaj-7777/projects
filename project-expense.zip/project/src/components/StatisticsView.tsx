import React, { useState } from 'react';
import { BarChart3, PieChart, Calendar, CreditCard, Filter } from 'lucide-react';
import { useAppContext } from '../context/AppContext';
import Card from './common/Card';
import { formatCurrency } from '../utils/calculations';

const StatisticsView: React.FC = () => {
  const { expenses, users, getUserById } = useAppContext();
  const [timeFilter, setTimeFilter] = useState('all'); // all, month, year

  // Filter expenses based on time period
  const filteredExpenses = expenses.filter(expense => {
    if (timeFilter === 'all') return true;
    
    const expenseDate = new Date(expense.date);
    const today = new Date();
    
    if (timeFilter === 'month') {
      return (
        expenseDate.getMonth() === today.getMonth() && 
        expenseDate.getFullYear() === today.getFullYear()
      );
    }
    
    if (timeFilter === 'year') {
      return expenseDate.getFullYear() === today.getFullYear();
    }
    
    return true;
  });

  // Calculate expenses by category
  const expensesByCategory: Record<string, number> = {};
  filteredExpenses.forEach(expense => {
    expensesByCategory[expense.category] = (expensesByCategory[expense.category] || 0) + expense.amount;
  });

  // Sort categories by amount (descending)
  const sortedCategories = Object.entries(expensesByCategory)
    .sort((a, b) => b[1] - a[1]);

  // Calculate expenses by user
  const expensesByUser: Record<string, number> = {};
  filteredExpenses.forEach(expense => {
    expensesByUser[expense.paidBy] = (expensesByUser[expense.paidBy] || 0) + expense.amount;
  });

  // Sort users by amount spent (descending)
  const sortedUserExpenses = Object.entries(expensesByUser)
    .sort((a, b) => b[1] - a[1]);

  // Calculate expenses by month (for current year)
  const expensesByMonth: Record<number, number> = {};
  filteredExpenses.forEach(expense => {
    const date = new Date(expense.date);
    const month = date.getMonth();
    expensesByMonth[month] = (expensesByMonth[month] || 0) + expense.amount;
  });

  // Get total expenses
  const totalExpenses = filteredExpenses.reduce((sum, expense) => sum + expense.amount, 0);

  // Get max value for bar chart scaling
  const maxCategoryAmount = sortedCategories.length > 0 ? sortedCategories[0][1] : 0;
  const maxUserAmount = sortedUserExpenses.length > 0 ? sortedUserExpenses[0][1] : 0;

  // Month names for the chart
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Statistics</h2>
        
        <div className="flex items-center space-x-2">
          <div className="text-sm text-gray-500 dark:text-gray-400 flex items-center">
            <Filter size={14} className="mr-1" />
            <span>Period:</span>
          </div>
          <select
            value={timeFilter}
            onChange={(e) => setTimeFilter(e.target.value)}
            className="text-sm rounded-md border border-gray-300 dark:border-gray-600 px-2 py-1 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:border-teal-500 focus:ring-teal-500"
          >
            <option value="all">All Time</option>
            <option value="month">This Month</option>
            <option value="year">This Year</option>
          </select>
        </div>
      </div>

      {/* Total Expenses Card */}
      <Card className="bg-gradient-to-r from-teal-500 to-indigo-500 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xl font-bold opacity-90">Total Expenses</h3>
            <p className="text-3xl font-bold mt-2">{formatCurrency(totalExpenses)}</p>
            <p className="mt-1 opacity-80">
              {timeFilter === 'all' ? 'All time' : timeFilter === 'month' ? 'This month' : 'This year'}
            </p>
          </div>
          <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
            <CreditCard size={32} className="text-white" />
          </div>
        </div>
      </Card>

      {filteredExpenses.length === 0 ? (
        <Card className="text-center py-8">
          <BarChart3 size={48} className="mx-auto text-gray-400 mb-3" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">No data to show</h3>
          <p className="text-gray-500 dark:text-gray-400">
            There are no expenses for the selected time period.
          </p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Expenses by Category */}
          <Card heading="Expenses by Category">
            <div className="flex items-center mb-3">
              <PieChart size={18} className="text-indigo-500 mr-2" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Categories</h3>
            </div>
            
            <div className="space-y-4">
              {sortedCategories.map(([category, amount]) => {
                const percentage = (amount / totalExpenses) * 100;
                return (
                  <div key={category} className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {category}
                      </span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {formatCurrency(amount)} ({percentage.toFixed(1)}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                      <div 
                        className="bg-indigo-500 h-2.5 rounded-full" 
                        style={{ width: `${(amount / maxCategoryAmount) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Expenses by Person */}
          <Card heading="Expenses by Person">
            <div className="flex items-center mb-3">
              <BarChart3 size={18} className="text-teal-500 mr-2" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Spending by Person</h3>
            </div>
            
            <div className="space-y-4">
              {sortedUserExpenses.map(([userId, amount]) => {
                const user = getUserById(userId);
                const userName = user ? user.name : 'Unknown';
                const percentage = (amount / totalExpenses) * 100;
                
                return (
                  <div key={userId} className="space-y-1">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                        {userName}
                      </span>
                      <span className="text-sm text-gray-500 dark:text-gray-400">
                        {formatCurrency(amount)} ({percentage.toFixed(1)}%)
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2.5">
                      <div 
                        className="bg-teal-500 h-2.5 rounded-full" 
                        style={{ width: `${(amount / maxUserAmount) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </Card>

          {/* Monthly Expenses (Only visible for year or all time filters) */}
          {timeFilter !== 'month' && (
            <Card heading="Monthly Expenses" className="lg:col-span-2">
              <div className="flex items-center mb-4">
                <Calendar size={18} className="text-pink-500 mr-2" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                  Expense Trends by Month
                </h3>
              </div>
              
              <div className="h-64 flex items-end justify-between space-x-1 px-2">
                {monthNames.map((month, index) => {
                  const amount = expensesByMonth[index] || 0;
                  const maxMonthAmount = Math.max(...Object.values(expensesByMonth), 1);
                  const percentage = amount ? (amount / maxMonthAmount) * 100 : 0;
                  
                  return (
                    <div key={month} className="flex flex-col items-center flex-1">
                      <div 
                        className="w-full bg-gradient-to-t from-teal-500 to-indigo-500 rounded-t-md transition-all duration-500 hover:opacity-80"
                        style={{ height: `${percentage}%` }}
                      ></div>
                      <div className="text-xs mt-1 text-gray-600 dark:text-gray-400">
                        {month}
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
};

export default StatisticsView;