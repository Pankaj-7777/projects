import { Expense, Settlement, Balance, User } from '../types';

// Calculate the total balance for each user
export const calculateBalances = (expenses: Expense[], users: User[]): Balance[] => {
  const balances: Record<string, number> = {};
  
  // Initialize balances for all users
  users.forEach(user => {
    balances[user.id] = 0;
  });

  // Calculate balances based on expenses
  expenses.forEach(expense => {
    // Add amount to payer (positive balance)
    balances[expense.paidBy] = (balances[expense.paidBy] || 0) + expense.amount;
    
    // Subtract from participants (negative balance)
    expense.participants.forEach(participant => {
      balances[participant.userId] = (balances[participant.userId] || 0) - participant.amount;
    });
  });

  return Object.entries(balances).map(([userId, amount]) => ({
    userId,
    amount: parseFloat(amount.toFixed(2)),
  }));
};

// Calculate who owes whom
export const calculateSettlements = (balances: Balance[]): Settlement[] => {
  const settlements: Settlement[] = [];
  
  // Create a copy of balances to work with
  const workingBalances = [...balances];
  
  // Sort balances by amount (ascending)
  workingBalances.sort((a, b) => a.amount - b.amount);
  
  // Match debtors with creditors
  let i = 0; // index for negative balances (debtors)
  let j = workingBalances.length - 1; // index for positive balances (creditors)
  
  while (i < j) {
    const debtor = workingBalances[i];
    const creditor = workingBalances[j];
    
    // Skip zero balances
    if (Math.abs(debtor.amount) < 0.01) {
      i++;
      continue;
    }
    
    if (Math.abs(creditor.amount) < 0.01) {
      j--;
      continue;
    }
    
    // Calculate the settlement amount
    const settlementAmount = Math.min(Math.abs(debtor.amount), creditor.amount);
    
    if (settlementAmount > 0.01) {
      settlements.push({
        from: debtor.userId,
        to: creditor.userId,
        amount: parseFloat(settlementAmount.toFixed(2)),
      });
    }
    
    // Update balances
    workingBalances[i].amount += settlementAmount;
    workingBalances[j].amount -= settlementAmount;
    
    // Move indices if balances are settled
    if (Math.abs(workingBalances[i].amount) < 0.01) i++;
    if (Math.abs(workingBalances[j].amount) < 0.01) j--;
  }
  
  return settlements;
};

// Split expense equally
export const splitEqually = (expense: Expense, userIds: string[]): Expense => {
  const amountPerPerson = expense.amount / userIds.length;
  
  return {
    ...expense,
    participants: userIds.map(userId => ({
      userId,
      amount: parseFloat(amountPerPerson.toFixed(2)),
    })),
    splitMethod: 'equal',
  };
};

// Generate a unique ID
export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 11);
};

// Format currency
export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
};

// Format date
export const formatDate = (dateString: string): string => {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
};